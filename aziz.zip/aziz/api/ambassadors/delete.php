<?php
// File: api/ambassadors/delete.php
include_once '../db.php';
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    http_response_code(403);
    echo json_encode(["message" => "Access denied."]);
    exit;
}

$data = json_decode(file_get_contents("php://input"));

if (empty($data->id)) {
    http_response_code(400);
    echo json_encode(["message" => "ID is required."]);
    return;
}

$sql = "DELETE FROM ambassadors WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $data->id);

if ($stmt->execute()) {
    http_response_code(200);
    echo json_encode(["message" => "Ambassador was deleted."]);
} else {
    http_response_code(503);
    echo json_encode(["message" => "Unable to delete ambassador."]);
}
$conn->close();
?>