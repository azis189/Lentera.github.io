<?php
// File: api/ambassadors/update.php
include_once '../db.php';
session_start();

// 1. Cek Hak Akses Admin
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    http_response_code(403);
    echo json_encode(["message" => "Access denied. Anda harus login sebagai Admin."]);
    exit;
}

// 2. Ambil data JSON dari request
$data = json_decode(file_get_contents("php://input"));

// 3. Validasi data yang masuk
if (
    !isset($data->id) || 
    !isset($data->name) || 
    !isset($data->details) || 
    !isset($data->achievement) || 
    !isset($data->img_url) ||
    empty(trim($data->name)) ||
    empty(trim($data->details)) ||
    empty(trim($data->achievement)) ||
    empty(trim($data->img_url))
) {
    http_response_code(400);
    echo json_encode(["message" => "Data tidak lengkap. Semua field wajib diisi."]);
    exit;
}

// 4. Siapkan dan jalankan query UPDATE ke database
$sql = "UPDATE ambassadors SET name = ?, details = ?, achievement = ?, img_url = ? WHERE id = ?";
$stmt = $conn->prepare($sql);

// Periksa apakah prepare statement berhasil
if ($stmt === false) {
    http_response_code(500);
    echo json_encode(["message" => "Internal Server Error: Gagal menyiapkan statement.", "error" => $conn->error]);
    exit;
}

$stmt->bind_param("ssssi", $data->name, $data->details, $data->achievement, $data->img_url, $data->id);

// 5. Kirim respon berdasarkan hasil eksekusi query
if ($stmt->execute()) {
    // Cek apakah ada baris yang benar-benar terpengaruh (diperbarui)
    if ($stmt->affected_rows > 0) {
        http_response_code(200);
        echo json_encode(["message" => "Ambassador was updated successfully."]);
    } else {
        http_response_code(200);
        echo json_encode(["message" => "No changes were made to the ambassador record."]);
    }
} else {
    http_response_code(503);
    echo json_encode(["message" => "Unable to update ambassador.", "error" => $stmt->error]);
}

$stmt->close();
$conn->close();
?>
