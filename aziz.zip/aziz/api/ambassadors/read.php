<?php
// File: api/ambassadors/read.php
include_once '../db.php';

$sql = "SELECT id, name, details, achievement, img_url FROM ambassadors ORDER BY id DESC";
$result = $conn->query($sql);

$ambassadors_arr = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        array_push($ambassadors_arr, $row);
    }
    http_response_code(200);
    echo json_encode($ambassadors_arr);
} else {
    http_response_code(200);
    echo json_encode([]);
}
$conn->close();
?>