<?php
// File: api/reviews/create.php
include_once '../db.php';
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    http_response_code(403);
    echo json_encode(["message" => "Access denied."]);
    exit;
}

// Data from POST request
$siswa = $_POST['siswa'] ?? '';
$kelas = $_POST['kelas'] ?? '';
$judul_buku = $_POST['judul_buku'] ?? '';
$identitas = $_POST['identitas'] ?? 0;
$isi = $_POST['isi'] ?? 0;
$bahasa = $_POST['bahasa'] ?? 0;
$kesimpulan = $_POST['kesimpulan'] ?? 0;
$img_path = null;

// Handle file upload
if (isset($_FILES['imgFile']) && $_FILES['imgFile']['error'] == 0) {
    $target_dir = "../../uploads/"; // Relative to the script's location
    // Create a unique filename
    $imageFileType = strtolower(pathinfo($_FILES["imgFile"]["name"], PATHINFO_EXTENSION));
    $target_file = $target_dir . uniqid('review_') . '.' . $imageFileType;
    $uploadOk = 1;

    // Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["imgFile"]["tmp_name"]);
    if($check === false) {
        http_response_code(400);
        echo json_encode(["message" => "File is not an image."]);
        exit();
    }

    // Check file size (e.g., 5MB limit)
    if ($_FILES["imgFile"]["size"] > 5000000) {
        http_response_code(400);
        echo json_encode(["message" => "Sorry, your file is too large."]);
        exit();
    }

    // Allow certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
        http_response_code(400);
        echo json_encode(["message" => "Sorry, only JPG, JPEG, PNG & GIF files are allowed."]);
        exit();
    }
    
    if (move_uploaded_file($_FILES["imgFile"]["tmp_name"], $target_file)) {
        // Path to be stored in DB should be relative to index.html
        $img_path = "uploads/" . basename($target_file);
    } else {
        http_response_code(503);
        echo json_encode(["message" => "Sorry, there was an error uploading your file."]);
        exit();
    }
}

$sql = "INSERT INTO reviews (siswa, kelas, judul_buku, identitas, isi, bahasa, kesimpulan, img_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssiisss", $siswa, $kelas, $judul_buku, $identitas, $isi, $bahasa, $kesimpulan, $img_path);

if ($stmt->execute()) {
    http_response_code(201);
    echo json_encode(["message" => "Review was created."]);
} else {
    http_response_code(503);
    echo json_encode(["message" => "Unable to create review."]);
}
$conn->close();
?>