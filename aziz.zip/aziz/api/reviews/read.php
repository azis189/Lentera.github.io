<?php
// File: api/reviews/read.php
include_once '../db.php';

$sql = "SELECT id, siswa, kelas, judul_buku, identitas, isi, bahasa, kesimpulan, img_path FROM reviews ORDER BY id DESC";
$result = $conn->query($sql);

$reviews_arr = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        // Calculate total points
        $row['total_points'] = $row['identitas'] + $row['isi'] + $row['bahasa'] + $row['kesimpulan'];
        array_push($reviews_arr, $row);
    }
    http_response_code(200);
    echo json_encode($reviews_arr);
} else {
    http_response_code(200);
    echo json_encode([]);
}
$conn->close();
?>