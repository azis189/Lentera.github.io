<?php
// File: api/reviews/delete.php
include_once '../db.php';
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    http_response_code(403);
    echo json_encode(["message" => "Access denied."]);
    exit;
}

$data = json_decode(file_get_contents("php://input"));

if (empty($data->id)) {
    http_response_code(400);
    echo json_encode(["message" => "ID is required."]);
    return;
}

// Optional: Delete the image file from the server
$stmt_select = $conn->prepare("SELECT img_path FROM reviews WHERE id = ?");
$stmt_select->bind_param("i", $data->id);
$stmt_select->execute();
$result = $stmt_select->get_result();
if ($row = $result->fetch_assoc()) {
    if (!empty($row['img_path']) && file_exists("../../".$row['img_path'])) {
        unlink("../../".$row['img_path']);
    }
}
$stmt_select->close();

// Delete the record from the database
$sql = "DELETE FROM reviews WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $data->id);

if ($stmt->execute()) {
    http_response_code(200);
    echo json_encode(["message" => "Review was deleted."]);
} else {
    http_response_code(503);
    echo json_encode(["message" => "Unable to delete review."]);
}
$conn->close();
?>