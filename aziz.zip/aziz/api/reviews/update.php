<?php
// File: api/reviews/update.php
include_once '../db.php';
session_start();

// 1. Cek Hak Akses Admin
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    http_response_code(403);
    echo json_encode(["message" => "Access denied. Anda harus login sebagai Admin."]);
    exit;
}

// 2. Ambil data dari request (multipart/form-data)
$id = $_POST['id'] ?? 0;
$siswa = $_POST['siswa'] ?? '';
$kelas = $_POST['kelas'] ?? '';
$judul_buku = $_POST['judul_buku'] ?? '';
$identitas = $_POST['identitas'] ?? 0;
$isi = $_POST['isi'] ?? 0;
$bahasa = $_POST['bahasa'] ?? 0;
$kesimpulan = $_POST['kesimpulan'] ?? 0;
$new_img_path = null;

if (empty($id) || empty($siswa) || empty($kelas) || empty($judul_buku)) {
    http_response_code(400);
    echo json_encode(["message" => "Data tidak lengkap. Semua field teks wajib diisi."]);
    exit;
}

// 3. Proses Upload Gambar Baru (jika ada)
if (isset($_FILES['imgFile']) && $_FILES['imgFile']['error'] == UPLOAD_ERR_OK) {
    // Ambil path gambar lama untuk dihapus nanti
    $stmt_old_img = $conn->prepare("SELECT img_path FROM reviews WHERE id = ?");
    $stmt_old_img->bind_param("i", $id);
    $stmt_old_img->execute();
    $result_old_img = $stmt_old_img->get_result();
    $old_img_path_row = $result_old_img->fetch_assoc();
    $old_img_path = $old_img_path_row ? "../../" . $old_img_path_row['img_path'] : null;
    $stmt_old_img->close();

    // Validasi dan simpan file baru
    $target_dir = "../../uploads/";
    $imageFileType = strtolower(pathinfo($_FILES["imgFile"]["name"], PATHINFO_EXTENSION));
    $target_file = $target_dir . uniqid('review_') . '.' . $imageFileType;
    
    // Cek validitas file
    if (getimagesize($_FILES["imgFile"]["tmp_name"]) === false) {
        http_response_code(400); echo json_encode(["message" => "File bukan gambar."]); exit();
    }
    if ($_FILES["imgFile"]["size"] > 5000000) { // 5MB limit
        http_response_code(400); echo json_encode(["message" => "Ukuran file terlalu besar."]); exit();
    }
    if (!in_array($imageFileType, ["jpg", "png", "jpeg", "gif"])) {
        http_response_code(400); echo json_encode(["message" => "Hanya format JPG, JPEG, PNG & GIF yang diizinkan."]); exit();
    }

    // Pindahkan file baru dan hapus yang lama
    if (move_uploaded_file($_FILES["imgFile"]["tmp_name"], $target_file)) {
        $new_img_path = "uploads/" . basename($target_file); // Path untuk disimpan di DB
        // Hapus file gambar lama jika ada
        if ($old_img_path && file_exists($old_img_path)) {
            unlink($old_img_path);
        }
    } else {
        http_response_code(503);
        echo json_encode(["message" => "Gagal mengunggah file baru."]);
        exit();
    }
}

// 4. Siapkan dan jalankan query UPDATE ke database
$sql = "";
$stmt = null;

if ($new_img_path !== null) {
    // Query jika ada gambar baru
    $sql = "UPDATE reviews SET siswa = ?, kelas = ?, judul_buku = ?, identitas = ?, isi = ?, bahasa = ?, kesimpulan = ?, img_path = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssiisisi", $siswa, $kelas, $judul_buku, $identitas, $isi, $bahasa, $kesimpulan, $new_img_path, $id);
} else {
    // Query jika tidak ada gambar baru
    $sql = "UPDATE reviews SET siswa = ?, kelas = ?, judul_buku = ?, identitas = ?, isi = ?, bahasa = ?, kesimpulan = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssiisii", $siswa, $kelas, $judul_buku, $identitas, $isi, $bahasa, $kesimpulan, $id);
}

// 5. Kirim respon
if ($stmt->execute()) {
    http_response_code(200);
    echo json_encode(["message" => "Review was updated successfully."]);
} else {
    http_response_code(503);
    echo json_encode(["message" => "Unable to update review.", "error" => $stmt->error]);
}

$stmt->close();
$conn->close();
?>
