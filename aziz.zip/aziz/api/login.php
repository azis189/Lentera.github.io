<?php
// File: api/login.php
session_start();
include_once 'db.php'; // Pastikan file db.php ada dan berisi koneksi database yang benar

$data = json_decode(file_get_contents("php://input"));

// Validasi input awal: pastikan username dan password ada
if (!isset($data->username) || !isset($data->password)) {
    http_response_code(400); // Bad Request
    echo json_encode(["message" => "Username dan password diperlukan.", "success" => false]);
    exit();
}

$username = $conn->real_escape_string($data->username);
$password = $data->password; // Kata sandi mentah dari pengguna

// Siapkan dan eksekusi statement SQL untuk mencegah SQL Injection
$sql = "SELECT * FROM users WHERE username = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    // Tangani error jika prepare gagal
    http_response_code(500);
    echo json_encode(["message" => "Terjadi kesalahan server saat menyiapkan query.", "success" => false]);
    $conn->close();
    exit();
}

$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();

    // Verifikasi kata sandi yang benar
    // $password adalah kata sandi yang dimasukkan pengguna (plain text)
    // $user['password'] adalah kata sandi ter-hash dari database
    if (password_verify($password, $user['password'])) {
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $user['username'];
        http_response_code(200); // OK
        echo json_encode(["message" => "Login berhasil.", "success" => true]);
    } else {
        // Jika kata sandi tidak cocok
        http_response_code(401); // Unauthorized
        echo json_encode(["message" => "Username atau password salah.", "success" => false]);
    }
} else {
    // Jika username tidak ditemukan
    http_response_code(401); // Unauthorized
    echo json_encode(["message" => "Username atau password salah.", "success" => false]);
}

// Tutup statement dan koneksi database
$stmt->close();
$conn->close();
?>
