<?php
// File: api/borrowing/read.php
include_once '../db.php';

$sql = "SELECT id, siswa, kelas, judul_buku, tanggal_pinjam, tanggal_kembali FROM borrowing ORDER BY id DESC";
$result = $conn->query($sql);

$borrowing_arr = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        array_push($borrowing_arr, $row);
    }
    http_response_code(200);
    echo json_encode($borrowing_arr);
} else {
    http_response_code(200);
    echo json_encode([]);
}
$conn->close();
?>
