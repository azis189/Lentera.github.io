<?php
// File: api/borrowing/update.php
include_once '../db.php';
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    http_response_code(403);
    echo json_encode(["message" => "Access denied."]);
    exit;
}

$data = json_decode(file_get_contents("php://input"));

if (empty($data->id) || empty($data->siswa) || empty($data->kelas) || empty($data->judul_buku) || empty($data->tanggal_pinjam)) {
    http_response_code(400);
    echo json_encode(["message" => "Incomplete data."]);
    return;
}

$tanggal_kembali = !empty($data->tanggal_kembali) ? $data->tanggal_kembali : NULL;

$sql = "UPDATE borrowing SET siswa = ?, kelas = ?, judul_buku = ?, tanggal_pinjam = ?, tanggal_kembali = ? WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssi", $data->siswa, $data->kelas, $data->judul_buku, $data->tanggal_pinjam, $tanggal_kembali, $data->id);

if ($stmt->execute()) {
    http_response_code(200);
    echo json_encode(["message" => "Record was updated."]);
} else {
    http_response_code(503);
    echo json_encode(["message" => "Unable to update record."]);
}
$conn->close();
?>