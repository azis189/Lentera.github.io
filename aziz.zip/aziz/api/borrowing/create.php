<?php
// File: api/borrowing/create.php
include_once '../db.php';
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    http_response_code(403);
    echo json_encode(["message" => "Access denied."]);
    exit;
}

$data = json_decode(file_get_contents("php://input"));

if (empty($data->siswa) || empty($data->kelas) || empty($data->judul_buku) || empty($data->tanggal_pinjam)) {
    http_response_code(400);
    echo json_encode(["message" => "Incomplete data."]);
    return;
}

$tanggal_kembali = !empty($data->tanggal_kembali) ? $data->tanggal_kembali : NULL;

$sql = "INSERT INTO borrowing (siswa, kelas, judul_buku, tanggal_pinjam, tanggal_kembali) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssss", $data->siswa, $data->kelas, $data->judul_buku, $data->tanggal_pinjam, $tanggal_kembali);

if ($stmt->execute()) {
    http_response_code(201);
    echo json_encode(["message" => "Record was created."]);
} else {
    http_response_code(503);
    echo json_encode(["message" => "Unable to create record."]);
}
$conn->close();
?>