<?php
// File: api/logout.php
session_start();
session_unset();
session_destroy();

// Set header for JSON response
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

http_response_code(200);
echo json_encode(["message" => "Logout successful.", "success" => true]);
?>
