<?php
// File: api/db.php

// Set header untuk output JSON
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, GET, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Handle preflight request (OPTIONS)
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// --- GANTI DETAIL INI DENGAN PENGATURAN DATABASE ANDA ---
$servername = "localhost"; // atau alamat IP server database Anda
$username = "root";        // username database Anda
$password = "";            // password database Anda
$dbname = "db_perpustakaan_sekolah"; // nama database Anda
// ---------------------------------------------------------

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    // Kirim response error jika koneksi gagal
    http_response_code(500);
    echo json_encode(["message" => "Connection failed: " . $conn->connect_error]);
    exit();
}

// Atur charset ke utf8mb4 untuk mendukung karakter yang lebih luas
$conn->set_charset("utf8mb4");

?>
