<?php
// File: api/about/read.php
include_once '../db.php';

$sql = "SELECT content FROM about WHERE id = 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    http_response_code(200);
    echo json_encode($row);
} else {
    http_response_code(404);
    echo json_encode(["content" => "Content not found."]);
}
$conn->close();
?>